// document.addEventListener("DOMContentLoaded", function () {
//     const limiteDeLetrasD = 5;
//     const limiteDeLetrasT = 2;

//     const descricao = document.getElementsByClassName("descricao");
//     const titulo = document.getElementsByClassName("titulo");

//     const textoD = descricao.innerText;
//     const textoT = titulo.innerText;

//     if (textoD.length > limiteDeLetrasD) {
//         let cortadaDescricao = textoD.slice(0, limiteDeLetrasD) + "...";
//         descricao.innerText = cortadaDescricao;
//     }

//     if (textoT.length > limiteDeLetrasT) {
//         let cortadoTitulo = textoT.slice(0, limiteDeLetrasT) + "...";
//         titulo.innerText = cortadoTitulo;
//     }
// });
